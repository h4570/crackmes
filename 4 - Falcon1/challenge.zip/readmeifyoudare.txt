Falcon1Crackme1 by Falcon1(of course)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released At: 15-1-2006
~~~~~~~~~~~~~~~~~~~~~

Info
~~~~
This crackme uses some anti-debugging tricks and a keyfile check...

Patching is only allowed in bypassing the anti-debugging tricks...

Objective: Make a keyfile creator...


Greets and thankx go to all the members of BiW


Falcon1
http://falcon1.5gigs.com