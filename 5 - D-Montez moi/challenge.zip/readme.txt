D-Montez moi by waganono
Level : 2

Just a small keygenme, nothing really special apart some little tricks :)
You have to print success message.

I hope you'll enjoy it.
waganono@free.fr